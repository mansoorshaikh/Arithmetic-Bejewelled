package com.example.airthmeticbejewelled;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import android.app.Activity;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.LinearInterpolator;
import android.view.animation.Transformation;
import android.widget.Button;
import android.widget.RelativeLayout;

public class GameFunctions {
	MediaPlayer mediaPlayer;

	Typeface font;
	int counterfor3digitequation = 0;
	int counterfor5digitequation = 0;
	int counterfor7digitequation = 0;
	public static int ANIMATION_DURATION = 500;
	Random r;
	String random3digitstart, fivedigitstart, sevendigitstart;
	ArrayList<String> three_DigitEquationArraylist = new ArrayList<String>();
	ArrayList<String> five_DigitEquationArraylist = new ArrayList<String>();
	ArrayList<String> seven_DigitEquationArraylist = new ArrayList<String>();
	String[] elementsArray = { "7", "8", "9" };
	String[] plusminusArray = { "+", "-" };
	String[] plusminuselementsArray = { "+" };
	String[] threerandomposition = { "10", "18", "26", "34", "42", "50", "58" };
	String[] fiverandomposition = { "6", "7", "14", "15", "22" };
	String[] sevenrandomposition = { "5", "13", "14", "15" };
	String rightLimitArray[] = { "57", "58", "59", "60", "61", "62", "63", "64" };
	String leftLimitArray[] = { "1", "2", "3", "4", "5", "6", "7", "8" };
	String topLimitArray[] = { "1", "9", "17", "25", "33", "41", "49", "57" };
	String bottomLimitArray[] = { "8", "16", "24", "32", "40", "48", "56", "64" };
	ArrayList<Button> matchingeqnButtonList = new ArrayList<Button>();
	int result, threedigitequationcount = 0, fivedigitequationcount = 0,
			sevendigitequationcount = 0, randomcombination = 0,
			gameplaycount = 0, threedigitresultindex = 0,
			fivesevendigitresultindex = 0, score = 0;
	Activity context;
	int currenttoplimit = 0, currentLeftLimit = 0, rightcellsremaining = 0,
			topcellsremaining = 0, bottomcellsremaining = 0,
			leftcellsremaining = 0;
	Button currentRowSelectedButton = null, currentSwipedButton = null;
	Button firstButton_7parteqn, secondButton_7partqn, thirdButton_7partqn,
			forthButton_7partqn, fifthButton_7partqn, sixthButton_7partqn,
			seventhButton_7partqn, eighthButton_7partqn;
	int randomswapposition_7digit = -1, randomswapposition_5digit = -1,
			randomswapposition_3digit = -1;
	String currentPlusMinusOdd = "";

	public GameFunctions(Activity context) {
		// TODO Auto-generated constructor stub
		this.context = context;
		r = new Random();
		font = Typeface.createFromAsset(context.getAssets(), "theboldfont.ttf");
	}

	void matchEquations() {
		try {
			rightcellsremaining = noofCells("right",
					currentRowSelectedButton.getId());
			topcellsremaining = noofCells("top",
					currentRowSelectedButton.getId());
			bottomcellsremaining = noofCells("bottom",
					currentRowSelectedButton.getId());
			leftcellsremaining = noofCells("left",
					currentRowSelectedButton.getId());
			if (calculateRightToLeftEquationMatch() == 0) {
				if (calculateToptoBottomEquationMatch() == 0) {
					if (GameActivity.directionString.equals("down")) {
						System.out
								.println("equation not matched, swiped down back");
						reverseDownAnimation();
					} else if (GameActivity.directionString.equals("up")) {
						System.out
								.println("equation not matched, swiped up back");
						reverseUpAnimation();
					} else if (GameActivity.directionString.equals("left")) {
						System.out
								.println("equation not matched, swiped left back");
						reverseLeftAnimation();
					} else if (GameActivity.directionString.equals("right")) {
						System.out
								.println("equation not matched, swiped right back");
						reverseRightAnimation();
					}
				} else {
					showCorrectResultAnimation(matchingeqnButtonList);
				}
			} else {
				showCorrectResultAnimation(matchingeqnButtonList);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	void reverseRightAnimation() {
		try {
			RelativeLayout.LayoutParams params1 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
					.getLayoutParams();
			RelativeLayout.LayoutParams params2 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
					.getLayoutParams();
			GameActivity.tempSwipeButton1.setLayoutParams(params2);
			GameActivity.tempSwipeButton2.setLayoutParams(params1);

			Animation a = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
							.getLayoutParams();
					params.rightMargin = (int) (GameActivity.tempSwipeButton1
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton1.setLayoutParams(params);
				}
			};
			a.setDuration(500); // in ms

			a.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton1
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton1);

				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

			GameActivity.tempSwipeButton1.startAnimation(a);

			Animation a2 = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
							.getLayoutParams();
					params.leftMargin = (int) (GameActivity.tempSwipeButton2
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton2.setLayoutParams(params);

				}
			};
			a2.setDuration(500); // in ms
			GameActivity.tempSwipeButton2.startAnimation(a2);

			a2.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton2
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton2);
					String currentswipetext = currentRowSelectedButton
							.getText().toString();
					currentRowSelectedButton.setText(currentSwipedButton
							.getText().toString());
					currentSwipedButton.setText(currentswipetext);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	void reverseLeftAnimation() {
		try {
			RelativeLayout.LayoutParams params1 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
					.getLayoutParams();
			RelativeLayout.LayoutParams params2 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
					.getLayoutParams();
			GameActivity.tempSwipeButton1.setLayoutParams(params2);
			GameActivity.tempSwipeButton2.setLayoutParams(params1);

			Animation a = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
							.getLayoutParams();
					params.leftMargin = (int) (GameActivity.tempSwipeButton1
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton1.setLayoutParams(params);
				}
			};
			a.setDuration(500); // in ms

			a.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton1
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton1);

				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

			GameActivity.tempSwipeButton1.startAnimation(a);

			Animation a2 = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
							.getLayoutParams();
					params.rightMargin = (int) (GameActivity.tempSwipeButton2
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton2.setLayoutParams(params);

				}
			};
			a2.setDuration(500); // in ms
			GameActivity.tempSwipeButton2.startAnimation(a2);

			a2.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton2
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton2);
					String currentswipetext = currentRowSelectedButton
							.getText().toString();
					currentRowSelectedButton.setText(currentSwipedButton
							.getText().toString());
					currentSwipedButton.setText(currentswipetext);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	void reverseUpAnimation() {
		try {
			RelativeLayout.LayoutParams params1 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
					.getLayoutParams();
			RelativeLayout.LayoutParams params2 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
					.getLayoutParams();
			GameActivity.tempSwipeButton1.setLayoutParams(params2);
			GameActivity.tempSwipeButton2.setLayoutParams(params1);

			Animation a = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
							.getLayoutParams();
					params.topMargin = (int) (GameActivity.tempSwipeButton1
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton1.setLayoutParams(params);
				}
			};
			a.setDuration(500); // in ms

			a.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton1
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton1);

				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

			GameActivity.tempSwipeButton1.startAnimation(a);

			Animation a2 = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
							.getLayoutParams();
					params.bottomMargin = (int) (GameActivity.tempSwipeButton2
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton2.setLayoutParams(params);

				}
			};
			a2.setDuration(500); // in ms
			GameActivity.tempSwipeButton2.startAnimation(a2);

			a2.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton2
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton2);
					String currentswipetext = currentRowSelectedButton
							.getText().toString();
					currentRowSelectedButton.setText(currentSwipedButton
							.getText().toString());
					currentSwipedButton.setText(currentswipetext);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	void reverseDownAnimation() {
		try {
			RelativeLayout.LayoutParams params1 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
					.getLayoutParams();
			RelativeLayout.LayoutParams params2 = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
					.getLayoutParams();
			GameActivity.tempSwipeButton1.setLayoutParams(params2);
			GameActivity.tempSwipeButton2.setLayoutParams(params1);

			Animation a = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton1
							.getLayoutParams();
					params.bottomMargin = (int) (GameActivity.tempSwipeButton1
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton1.setLayoutParams(params);
				}
			};
			a.setDuration(500); // in ms

			a.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton1
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton1);

				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

			GameActivity.tempSwipeButton1.startAnimation(a);

			Animation a2 = new Animation() {
				@Override
				protected void applyTransformation(float interpolatedTime,
						Transformation t) {
					RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) GameActivity.tempSwipeButton2
							.getLayoutParams();
					params.topMargin = (int) (GameActivity.tempSwipeButton2
							.getWidth() * interpolatedTime);
					GameActivity.tempSwipeButton2.setLayoutParams(params);

				}
			};
			a2.setDuration(500); // in ms
			GameActivity.tempSwipeButton2.startAnimation(a2);

			a2.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton2
							.getParent();
					if (viewParent != null)
						viewParent.removeView(GameActivity.tempSwipeButton2);

					String currentswipetext = currentRowSelectedButton
							.getText().toString();
					currentRowSelectedButton.setText(currentSwipedButton
							.getText().toString());
					currentSwipedButton.setText(currentswipetext);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	void fillRandomValues() {
		for (int count = 1; count < 65; count++) {
			Button eqnButton = (Button) GameActivity.gameLinearLayout
					.findViewById(count);
			String randomElement = elementsArray[getRandomBlankPosition(elementsArray.length)];
			String plusminusElement = plusminusArray[getRandomBlankPosition(plusminusArray.length)];
			if (eqnButton.getId() % 2 == 0)
				eqnButton.setText(plusminusElement);
			else
				eqnButton.setText(randomElement);
		}
	}

	int calculateRightToLeftEquationMatch() {
		try {
			firstButton_7parteqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit);
			secondButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 8);
			thirdButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 16);
			forthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 24);
			fifthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 32);
			sixthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 40);
			seventhButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 48);
			eighthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 56);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return checkEquationMatching("left-right");
	}

	// checks grid for the equations not be there on start
	void checkGridForDefaultEquations() {

		for (int count = 0; count < topLimitArray.length; count++) {
			currenttoplimit = Integer.parseInt(topLimitArray[count]);
			firstButton_7parteqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit);
			secondButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 1);
			thirdButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 2);
			forthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 3);
			fifthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 4);
			sixthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 5);
			seventhButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 6);
			eighthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 7);
			currentRowSelectedButton = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(topLimitArray[count]));
			checkGridOnStart("top-bottom");
		}

		for (int count = 0; count < leftLimitArray.length; count++) {
			currentLeftLimit = Integer.parseInt(leftLimitArray[count]);
			firstButton_7parteqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit);
			secondButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 8);
			thirdButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 16);
			forthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 24);
			fifthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 32);
			sixthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 40);
			seventhButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 48);
			eighthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currentLeftLimit + 56);
			currentRowSelectedButton = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(leftLimitArray[count]));
			checkGridOnStart("left-right");
		}
	}

	int checkGridOnStart(String direction) {
		if (isOperator(secondButton_7partqn.getText().toString())
				&& isOperator(forthButton_7partqn.getText().toString())
				&& isOperator(sixthButton_7partqn.getText().toString())
				&& secondButton_7partqn.getId() != randomswapposition_7digit
				&& forthButton_7partqn.getId() != randomswapposition_7digit
				&& sixthButton_7partqn.getId() != randomswapposition_7digit
				&& randomswapposition_7digit != -1) {
			if (isNumeric(firstButton_7parteqn.getText().toString())
					&& isNumeric(thirdButton_7partqn.getText().toString())
					&& isNumeric(fifthButton_7partqn.getText().toString())
					&& isNumeric(seventhButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_7PartEqn(
						secondButton_7partqn.getText().toString(),
						forthButton_7partqn.getText().toString(),
						sixthButton_7partqn.getText().toString(),
						firstButton_7parteqn.getText().toString(),
						thirdButton_7partqn.getText().toString(),
						fifthButton_7partqn.getText().toString(),
						seventhButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(firstButton_7parteqn);
					setRandomElement_OnStart(thirdButton_7partqn);
					setRandomElement_OnStart(fifthButton_7partqn);
					setRandomElement_OnStart(fifthButton_7partqn);
					return 1;
				} else {

				}
			}
		}
		if (isOperator(thirdButton_7partqn.getText().toString())
				&& isOperator(fifthButton_7partqn.getText().toString())
				&& isOperator(seventhButton_7partqn.getText().toString())
				&& thirdButton_7partqn.getId() != randomswapposition_7digit
				&& fifthButton_7partqn.getId() != randomswapposition_7digit
				&& seventhButton_7partqn.getId() != randomswapposition_7digit
				&& randomswapposition_7digit != -1) {
			if (isNumeric(secondButton_7partqn.getText().toString())
					&& isNumeric(forthButton_7partqn.getText().toString())
					&& isNumeric(sixthButton_7partqn.getText().toString())
					&& isNumeric(eighthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_7PartEqn(thirdButton_7partqn
						.getText().toString(), fifthButton_7partqn.getText()
						.toString(),
						seventhButton_7partqn.getText().toString(),
						secondButton_7partqn.getText().toString(),
						forthButton_7partqn.getText().toString(),
						sixthButton_7partqn.getText().toString(),
						eighthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(secondButton_7partqn);
					setRandomElement_OnStart(forthButton_7partqn);
					setRandomElement_OnStart(sixthButton_7partqn);
					setRandomElement_OnStart(eighthButton_7partqn);
					return 1;
				}
			}
		}
		if (isOperator(secondButton_7partqn.getText().toString())
				&& isOperator(forthButton_7partqn.getText().toString())
				&& secondButton_7partqn.getId() != randomswapposition_7digit
				&& forthButton_7partqn.getId() != randomswapposition_7digit
				&& randomswapposition_5digit != -1) {
			if (isNumeric(firstButton_7parteqn.getText().toString())
					&& isNumeric(thirdButton_7partqn.getText().toString())
					&& isNumeric(fifthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_5PartEqn(
						secondButton_7partqn.getText().toString(),
						forthButton_7partqn.getText().toString(),
						firstButton_7parteqn.getText().toString(),
						thirdButton_7partqn.getText().toString(),
						fifthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(firstButton_7parteqn);
					setRandomElement_OnStart(firstButton_7parteqn);
					setRandomElement_OnStart(fifthButton_7partqn);
					return 1;
				}
			}
		}
		if (isOperator(thirdButton_7partqn.getText().toString())
				&& isOperator(fifthButton_7partqn.getText().toString())
				&& thirdButton_7partqn.getId() != randomswapposition_7digit
				&& fifthButton_7partqn.getId() != randomswapposition_7digit
				&& randomswapposition_5digit != -1) {
			if (isNumeric(secondButton_7partqn.getText().toString())
					&& isNumeric(forthButton_7partqn.getText().toString())
					&& isNumeric(sixthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_5PartEqn(thirdButton_7partqn
						.getText().toString(), fifthButton_7partqn.getText()
						.toString(), secondButton_7partqn.getText().toString(),
						forthButton_7partqn.getText().toString(),
						sixthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(secondButton_7partqn);
					setRandomElement_OnStart(secondButton_7partqn);
					setRandomElement_OnStart(sixthButton_7partqn);
					return 1;
				} else {
				}
			}
		}
		if (isOperator(forthButton_7partqn.getText().toString())
				&& isOperator(sixthButton_7partqn.getText().toString())
				&& forthButton_7partqn.getId() != randomswapposition_7digit
				&& sixthButton_7partqn.getId() != randomswapposition_7digit
				&& randomswapposition_5digit != -1) {
			if (isNumeric(sixthButton_7partqn.getText().toString())
					&& isNumeric(fifthButton_7partqn.getText().toString())
					&& isNumeric(seventhButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_5PartEqn(forthButton_7partqn
						.getText().toString(), sixthButton_7partqn.getText()
						.toString(), thirdButton_7partqn.getText().toString(),
						fifthButton_7partqn.getText().toString(),
						seventhButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(sixthButton_7partqn);
					setRandomElement_OnStart(fifthButton_7partqn);
					setRandomElement_OnStart(seventhButton_7partqn);
					return 1;
				} else {
				}
			}
		}
		if (isOperator(fifthButton_7partqn.getText().toString())
				&& isOperator(seventhButton_7partqn.getText().toString())
				&& fifthButton_7partqn.getId() != randomswapposition_7digit
				&& seventhButton_7partqn.getId() != randomswapposition_7digit
				&& randomswapposition_5digit != -1) {
			if (isNumeric(forthButton_7partqn.getText().toString())
					&& isNumeric(sixthButton_7partqn.getText().toString())
					&& isNumeric(eighthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_5PartEqn(fifthButton_7partqn
						.getText().toString(), seventhButton_7partqn.getText()
						.toString(), forthButton_7partqn.getText().toString(),
						sixthButton_7partqn.getText().toString(),
						eighthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(forthButton_7partqn);
					setRandomElement_OnStart(sixthButton_7partqn);
					setRandomElement_OnStart(sixthButton_7partqn);
					return 1;
				} else {
				}
			}
		}
		if (isOperator(secondButton_7partqn.getText().toString())
				&& secondButton_7partqn.getId() != randomswapposition_3digit
				&& randomswapposition_3digit != -1) {
			if (isNumeric(firstButton_7parteqn.getText().toString())
					&& isNumeric(thirdButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_3PartEqn(
						secondButton_7partqn.getText().toString(),
						firstButton_7parteqn.getText().toString(),
						thirdButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(firstButton_7parteqn);
					setRandomElement_OnStart(thirdButton_7partqn);
					return 1;
				} else {

				}
			}
		}
		if (isOperator(thirdButton_7partqn.getText().toString())
				&& thirdButton_7partqn.getId() != randomswapposition_3digit
				&& randomswapposition_3digit != -1) {
			if (isNumeric(secondButton_7partqn.getText().toString())
					&& isNumeric(forthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_3PartEqn(thirdButton_7partqn
						.getText().toString(), secondButton_7partqn.getText()
						.toString(), forthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(secondButton_7partqn);
					setRandomElement_OnStart(forthButton_7partqn);
					return 1;
				} else {

				}
			}
		}
		if (isOperator(forthButton_7partqn.getText().toString())
				&& forthButton_7partqn.getId() != randomswapposition_3digit
				&& randomswapposition_3digit != -1) {
			if (isNumeric(thirdButton_7partqn.getText().toString())
					&& isNumeric(fifthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_3PartEqn(forthButton_7partqn
						.getText().toString(), thirdButton_7partqn.getText()
						.toString(), fifthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(thirdButton_7partqn);
					setRandomElement_OnStart(fifthButton_7partqn);
					return 1;
				} else {

				}
			}
		}
		if (isOperator(fifthButton_7partqn.getText().toString())
				&& fifthButton_7partqn.getId() != randomswapposition_3digit
				&& randomswapposition_3digit != -1) {
			if (isNumeric(forthButton_7partqn.getText().toString())
					&& isNumeric(sixthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_3PartEqn(fifthButton_7partqn
						.getText().toString(), forthButton_7partqn.getText()
						.toString(), sixthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(sixthButton_7partqn);
					setRandomElement_OnStart(forthButton_7partqn);
					return 1;
				} else {

				}
			}
		}
		if (isOperator(sixthButton_7partqn.getText().toString())
				&& sixthButton_7partqn.getId() != randomswapposition_3digit
				&& randomswapposition_3digit != -1) {
			if (isNumeric(fifthButton_7partqn.getText().toString())
					&& isNumeric(seventhButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_3PartEqn(sixthButton_7partqn
						.getText().toString(), fifthButton_7partqn.getText()
						.toString(), seventhButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(fifthButton_7partqn);
					setRandomElement_OnStart(seventhButton_7partqn);
					return 1;
				} else {

				}
			}
		}
		if (isOperator(seventhButton_7partqn.getText().toString())
				&& seventhButton_7partqn.getId() != randomswapposition_3digit
				&& randomswapposition_3digit != -1) {
			if (isNumeric(sixthButton_7partqn.getText().toString())
					&& isNumeric(eighthButton_7partqn.getText().toString())) {
				int currentresult = calculateValue_3PartEqn(
						seventhButton_7partqn.getText().toString(),
						sixthButton_7partqn.getText().toString(),
						eighthButton_7partqn.getText().toString());

				if (currentresult == result) {
					setRandomElement_OnStart(sixthButton_7partqn);
					setRandomElement_OnStart(eighthButton_7partqn);
					return 1;
				} else {

				}
			}
		}
		return 0;
	}

	int calculateToptoBottomEquationMatch() {
		try {
			firstButton_7parteqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit);
			secondButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 1);
			thirdButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 2);
			forthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 3);
			fifthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 4);
			sixthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 5);
			seventhButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 6);
			eighthButton_7partqn = (Button) GameActivity.gameLinearLayout
					.findViewById(currenttoplimit + 7);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return checkEquationMatching("top-bottom");

	}

	boolean checkRange_5PartEqn(int viewid, String direction) {
		try {
			if (direction.equals("top-bottom")) {
				if (Math.abs(viewid - currentRowSelectedButton.getId()) < 5)
					return true;
				else
					return false;
			} else if (direction.equals("left-right")) {
				if (Math.abs(viewid - currentRowSelectedButton.getId()) < 40)
					return true;
				else
					return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	boolean checkRange_3PartEqn(int viewid, String direction) {
		try {
			if (direction.equals("top-bottom")) {
				if (Math.abs(viewid - currentRowSelectedButton.getId()) < 3)
					return true;
				else
					return false;
			} else if (direction.equals("left-right")) {
				if (Math.abs(viewid - currentRowSelectedButton.getId()) < 24)
					return true;
				else
					return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	void setRandomElement_OnStart(Button eqnButton) {
		try {
			String randomElement = elementsArray[getRandomBlankPosition(elementsArray.length)];
			if (eqnButton.getText().toString().equals("+")
					|| eqnButton.getText().toString().equals("-")) {
				eqnButton.setText(randomElement);
			} else {
				if (Integer.parseInt(randomElement) > Integer
						.parseInt(eqnButton.getText().toString())) {
					eqnButton.setText(randomElement);
				} else {
					if (eqnButton.getText().toString().equals("+"))
						eqnButton.setText("-");
					else
						eqnButton.setText("+");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	void setRandomElementPlusMinus(Button eqnButton) {
		eqnButton.setText("+");
	}

	void setRandomElement(Button eqnButton) {
		try {
			String randomElement = elementsArray[getRandomBlankPosition(elementsArray.length)];
			if (eqnButton.getText().toString().equals("+")
					|| eqnButton.getText().toString().equals("-")) {
				eqnButton.setText(randomElement);
			} else {
				if (Integer.parseInt(randomElement) > Integer
						.parseInt(eqnButton.getText().toString())) {
					eqnButton.setText(randomElement);
				} else {
					eqnButton.setText(randomElement);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	void showCorrectResultAnimation(ArrayList<Button> buttonsList) {
		ViewGroup viewParent = (ViewGroup) GameActivity.tempSwipeButton1
				.getParent();
		if (viewParent != null) {
			viewParent.removeView(GameActivity.tempSwipeButton1);
			viewParent.removeView(GameActivity.tempSwipeButton2);
		}
		final Animation animation = new AlphaAnimation(1, 0);
		animation.setDuration(200);
		animation.setInterpolator(new LinearInterpolator());
		for (int count = 0; count < buttonsList.size(); count++) {

			buttonsList.get(count).startAnimation(animation);
			if (count == buttonsList.size() - 1) {
				animation.setAnimationListener(new AnimationListener() {

					@Override
					public void onAnimationStart(Animation animation) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onAnimationRepeat(Animation animation) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onAnimationEnd(Animation animation) {
						// TODO Auto-generated method stub
						fillGameValues(0);
					}
				});
			}
		}
	}

	void animateButtonFlash(Button btn) {

	}

	int checkEquationMatching(String direction) {
		matchingeqnButtonList.clear();
		try {
			if (isOperator(secondButton_7partqn.getText().toString())
					&& isOperator(forthButton_7partqn.getText().toString())
					&& isOperator(sixthButton_7partqn.getText().toString())) {
				if (isNumeric(firstButton_7parteqn.getText().toString())
						&& isNumeric(thirdButton_7partqn.getText().toString())
						&& isNumeric(fifthButton_7partqn.getText().toString())
						&& isNumeric(seventhButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_7PartEqn(
							secondButton_7partqn.getText().toString(),
							forthButton_7partqn.getText().toString(),
							sixthButton_7partqn.getText().toString(),
							firstButton_7parteqn.getText().toString(),
							thirdButton_7partqn.getText().toString(),
							fifthButton_7partqn.getText().toString(),
							seventhButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 7;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(secondButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(sixthButton_7partqn);
						setRandomElement(firstButton_7parteqn);
						setRandomElement(thirdButton_7partqn);
						setRandomElement(fifthButton_7partqn);
						setRandomElement(seventhButton_7partqn);

						matchingeqnButtonList.add(secondButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						matchingeqnButtonList.add(firstButton_7parteqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						matchingeqnButtonList.add(fifthButton_7partqn);
						matchingeqnButtonList.add(seventhButton_7partqn);

						return 1;
					}
				}
			}
			if (isOperator(thirdButton_7partqn.getText().toString())
					&& isOperator(fifthButton_7partqn.getText().toString())
					&& isOperator(seventhButton_7partqn.getText().toString())) {
				if (isNumeric(secondButton_7partqn.getText().toString())
						&& isNumeric(forthButton_7partqn.getText().toString())
						&& isNumeric(sixthButton_7partqn.getText().toString())
						&& isNumeric(eighthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_7PartEqn(
							thirdButton_7partqn.getText().toString(),
							fifthButton_7partqn.getText().toString(),
							seventhButton_7partqn.getText().toString(),
							secondButton_7partqn.getText().toString(),
							forthButton_7partqn.getText().toString(),
							sixthButton_7partqn.getText().toString(),
							eighthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 7;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(secondButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(sixthButton_7partqn);
						setRandomElement(eighthButton_7partqn);
						setRandomElement(thirdButton_7partqn);
						setRandomElement(fifthButton_7partqn);
						setRandomElement(seventhButton_7partqn);

						matchingeqnButtonList.add(secondButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						matchingeqnButtonList.add(eighthButton_7partqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						matchingeqnButtonList.add(fifthButton_7partqn);
						matchingeqnButtonList.add(seventhButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(secondButton_7partqn.getText().toString())
					&& isOperator(forthButton_7partqn.getText().toString())
					&& checkRange_5PartEqn(firstButton_7parteqn.getId(),
							direction)) {
				if (isNumeric(firstButton_7parteqn.getText().toString())
						&& isNumeric(thirdButton_7partqn.getText().toString())
						&& isNumeric(fifthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_5PartEqn(
							secondButton_7partqn.getText().toString(),
							forthButton_7partqn.getText().toString(),
							firstButton_7parteqn.getText().toString(),
							thirdButton_7partqn.getText().toString(),
							fifthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 5;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(secondButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(firstButton_7parteqn);
						setRandomElement(thirdButton_7partqn);
						setRandomElement(fifthButton_7partqn);

						matchingeqnButtonList.add(secondButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(firstButton_7parteqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						matchingeqnButtonList.add(fifthButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(thirdButton_7partqn.getText().toString())
					&& isOperator(fifthButton_7partqn.getText().toString())
					&& checkRange_5PartEqn(secondButton_7partqn.getId(),
							direction)) {
				if (isNumeric(secondButton_7partqn.getText().toString())
						&& isNumeric(forthButton_7partqn.getText().toString())
						&& isNumeric(sixthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_5PartEqn(
							thirdButton_7partqn.getText().toString(),
							fifthButton_7partqn.getText().toString(),
							secondButton_7partqn.getText().toString(),
							forthButton_7partqn.getText().toString(),
							sixthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 5;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(secondButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(sixthButton_7partqn);
						setRandomElement(thirdButton_7partqn);
						setRandomElement(fifthButton_7partqn);

						matchingeqnButtonList.add(secondButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						matchingeqnButtonList.add(fifthButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(forthButton_7partqn.getText().toString())
					&& isOperator(sixthButton_7partqn.getText().toString())
					&& checkRange_5PartEqn(thirdButton_7partqn.getId(),
							direction)) {
				if (isNumeric(thirdButton_7partqn.getText().toString())
						&& isNumeric(fifthButton_7partqn.getText().toString())
						&& isNumeric(seventhButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_5PartEqn(
							forthButton_7partqn.getText().toString(),
							sixthButton_7partqn.getText().toString(),
							thirdButton_7partqn.getText().toString(),
							fifthButton_7partqn.getText().toString(),
							seventhButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 5;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(seventhButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(sixthButton_7partqn);
						setRandomElement(thirdButton_7partqn);
						setRandomElement(fifthButton_7partqn);

						matchingeqnButtonList.add(seventhButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						matchingeqnButtonList.add(fifthButton_7partqn);

						return 1;
					}
				}
			}
			if (isOperator(fifthButton_7partqn.getText().toString())
					&& isOperator(seventhButton_7partqn.getText().toString())
					&& checkRange_5PartEqn(forthButton_7partqn.getId(),
							direction)) {
				if (isNumeric(forthButton_7partqn.getText().toString())
						&& isNumeric(sixthButton_7partqn.getText().toString())
						&& isNumeric(eighthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_5PartEqn(
							fifthButton_7partqn.getText().toString(),
							seventhButton_7partqn.getText().toString(),
							forthButton_7partqn.getText().toString(),
							sixthButton_7partqn.getText().toString(),
							eighthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 5;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(seventhButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(sixthButton_7partqn);
						setRandomElement(eighthButton_7partqn);
						setRandomElement(fifthButton_7partqn);

						matchingeqnButtonList.add(seventhButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						matchingeqnButtonList.add(eighthButton_7partqn);
						matchingeqnButtonList.add(fifthButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(secondButton_7partqn.getText().toString())
					&& checkRange_3PartEqn(firstButton_7parteqn.getId(),
							direction)) {
				if (isNumeric(firstButton_7parteqn.getText().toString())
						&& isNumeric(thirdButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_3PartEqn(
							secondButton_7partqn.getText().toString(),
							firstButton_7parteqn.getText().toString(),
							thirdButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 3;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(secondButton_7partqn);
						setRandomElement(firstButton_7parteqn);
						setRandomElement(thirdButton_7partqn);

						matchingeqnButtonList.add(secondButton_7partqn);
						matchingeqnButtonList.add(firstButton_7parteqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(thirdButton_7partqn.getText().toString())
					&& checkRange_3PartEqn(secondButton_7partqn.getId(),
							direction)) {
				if (isNumeric(secondButton_7partqn.getText().toString())
						&& isNumeric(forthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_3PartEqn(
							thirdButton_7partqn.getText().toString(),
							secondButton_7partqn.getText().toString(),
							forthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 3;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(secondButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(thirdButton_7partqn);

						matchingeqnButtonList.add(secondButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(forthButton_7partqn.getText().toString())
					&& checkRange_3PartEqn(thirdButton_7partqn.getId(),
							direction)) {
				if (isNumeric(thirdButton_7partqn.getText().toString())
						&& isNumeric(fifthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_3PartEqn(
							forthButton_7partqn.getText().toString(),
							thirdButton_7partqn.getText().toString(),
							fifthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 3;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(fifthButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(thirdButton_7partqn);

						matchingeqnButtonList.add(fifthButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(thirdButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(fifthButton_7partqn.getText().toString())
					&& checkRange_3PartEqn(forthButton_7partqn.getId(),
							direction)) {
				if (isNumeric(forthButton_7partqn.getText().toString())
						&& isNumeric(sixthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_3PartEqn(
							fifthButton_7partqn.getText().toString(),
							forthButton_7partqn.getText().toString(),
							sixthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 3;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(fifthButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(sixthButton_7partqn);

						matchingeqnButtonList.add(fifthButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(sixthButton_7partqn.getText().toString())
					&& checkRange_3PartEqn(fifthButton_7partqn.getId(),
							direction)) {
				if (isNumeric(fifthButton_7partqn.getText().toString())
						&& isNumeric(seventhButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_3PartEqn(
							sixthButton_7partqn.getText().toString(),
							fifthButton_7partqn.getText().toString(),
							seventhButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 3;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(fifthButton_7partqn);
						setRandomElement(forthButton_7partqn);
						setRandomElement(sixthButton_7partqn);

						matchingeqnButtonList.add(fifthButton_7partqn);
						matchingeqnButtonList.add(forthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						return 1;
					}
				}
			}
			if (isOperator(seventhButton_7partqn.getText().toString())
					&& checkRange_3PartEqn(sixthButton_7partqn.getId(),
							direction)) {
				if (isNumeric(sixthButton_7partqn.getText().toString())
						&& isNumeric(eighthButton_7partqn.getText().toString())) {
					int currentresult = calculateValue_3PartEqn(
							seventhButton_7partqn.getText().toString(),
							sixthButton_7partqn.getText().toString(),
							eighthButton_7partqn.getText().toString());

					if (currentresult == result) {
						score = score + 3;
						GameActivity.scoreTextView.setText(String
								.valueOf(score));
						setRandomElement(fifthButton_7partqn);
						setRandomElement(sixthButton_7partqn);
						setRandomElement(seventhButton_7partqn);

						matchingeqnButtonList.add(fifthButton_7partqn);
						matchingeqnButtonList.add(sixthButton_7partqn);
						matchingeqnButtonList.add(seventhButton_7partqn);
						return 1;
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return 0;
	}

	public static boolean isNumeric(String number) {
		try {
			int d = Integer.parseInt(number);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	int calculateValue_3PartEqn(String operator, String firstVal, String secVal) {
		try {
			if (operator.equals("+")) {
				return Integer.parseInt(firstVal) + Integer.parseInt(secVal);
			} else {
				return Integer.parseInt(firstVal) - Integer.parseInt(secVal);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}

	int calculateValue_5PartEqn(String operator1, String operator2,
			String firstVal, String secVal, String thirdVal) {
		try {
			if (operator1.equals("+") && operator2.equals("+")) {
				return Integer.parseInt(firstVal) + Integer.parseInt(secVal)
						+ Integer.parseInt(thirdVal);
			} else if (operator1.equals("+") && operator2.equals("-")) {
				return Integer.parseInt(firstVal) + Integer.parseInt(secVal)
						- Integer.parseInt(thirdVal);
			} else if (operator1.equals("-") && operator2.equals("+")) {
				return Integer.parseInt(firstVal) - Integer.parseInt(secVal)
						+ Integer.parseInt(thirdVal);
			} else {
				return Integer.parseInt(firstVal) - Integer.parseInt(secVal)
						- Integer.parseInt(thirdVal);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}

	int calculateValue_7PartEqn(String operator1, String operator2,
			String operator3, String firstVal, String secVal, String thirdVal,
			String fourthVal) {
		try {
			if (operator1.equals("+") && operator2.equals("+")
					&& operator3.equals("+")) {
				return Integer.parseInt(firstVal) + Integer.parseInt(secVal)
						+ Integer.parseInt(thirdVal)
						+ Integer.parseInt(fourthVal);
			} else if (operator1.equals("+") && operator2.equals("+")
					&& operator3.equals("-")) {
				return Integer.parseInt(firstVal) + Integer.parseInt(secVal)
						+ Integer.parseInt(thirdVal)
						- Integer.parseInt(fourthVal);
			} else if (operator1.equals("-") && operator2.equals("+")
					&& operator3.equals("+")) {
				return Integer.parseInt(firstVal) - Integer.parseInt(secVal)
						+ Integer.parseInt(thirdVal)
						+ Integer.parseInt(fourthVal);
			} else if (operator1.equals("-") && operator2.equals("-")
					&& operator3.equals("-")) {
				return Integer.parseInt(firstVal) - Integer.parseInt(secVal)
						- Integer.parseInt(thirdVal)
						- Integer.parseInt(fourthVal);
			} else if (operator1.equals("+") && operator2.equals("-")
					&& operator3.equals("-")) {
				return Integer.parseInt(firstVal) + Integer.parseInt(secVal)
						- Integer.parseInt(thirdVal)
						- Integer.parseInt(fourthVal);
			} else if (operator1.equals("+") && operator2.equals("-")
					&& operator3.equals("+")) {
				return Integer.parseInt(firstVal) + Integer.parseInt(secVal)
						- Integer.parseInt(thirdVal)
						+ Integer.parseInt(fourthVal);
			} else if (operator1.equals("-") && operator2.equals("+")
					&& operator3.equals("-")) {
				return Integer.parseInt(firstVal) - Integer.parseInt(secVal)
						+ Integer.parseInt(thirdVal)
						- Integer.parseInt(fourthVal);
			} else {
				return Integer.parseInt(firstVal) - Integer.parseInt(secVal)
						- Integer.parseInt(thirdVal)
						+ Integer.parseInt(fourthVal);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}

	public static boolean isOperator(String operator) {
		try {
			if (operator.equals("+") || operator.equals("-"))
				return true;
			else
				return false;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}

	int noofCells(String move, int viewid) {
		try {
			int rightcellsremaining = 1, topcellsremaining = 1, bottomcellsremaining = 1, leftcellsremaining = 1;
			if (move.equals("right")) {
				int currentview = viewid;
				if (viewid <= 56) {
					currentview = viewid - 8;
				}
				while (!Arrays.asList(rightLimitArray).contains(
						String.valueOf(currentview))) {
					rightcellsremaining++;
					currentview = currentview + 8;
				}
				System.out.println("rightcellsremaining" + rightcellsremaining);
				return rightcellsremaining;
			} else if (move.equals("left")) {
				int currentview = viewid;
				if (viewid > 8) {
					currentview = viewid - 8;
				}
				while (!Arrays.asList(leftLimitArray).contains(
						String.valueOf(currentview))) {
					leftcellsremaining++;
					currentview = currentview - 8;
				}
				System.out.println("leftcellsremaining" + leftcellsremaining);
				return leftcellsremaining;
			} else if (move.equals("top")) {
				int currentview = viewid;
				if (!Arrays.asList(topLimitArray).contains(
						String.valueOf(currentview)))
					currentview = viewid - 1;
				while (!Arrays.asList(topLimitArray).contains(
						String.valueOf(currentview))) {
					topcellsremaining++;
					currentview = currentview - 1;
				}
				System.out.println("topcellsremaining" + topcellsremaining);
				return topcellsremaining;
			} else if (move.equals("bottom")) {
				int currentview = viewid;
				if (!Arrays.asList(bottomLimitArray).contains(
						String.valueOf(currentview)))
					currentview = viewid + 1;
				while (!Arrays.asList(bottomLimitArray).contains(
						String.valueOf(currentview))) {
					bottomcellsremaining++;
					currentview = currentview + 1;
				}
				System.out.println("bottomcellsremaining"
						+ bottomcellsremaining);
				return bottomcellsremaining;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return 0;
	}

	int getRandomBlankPosition(int maxval) {
		Random r = new Random();
		return r.nextInt(maxval - 0) + 0;
	}

	int getTopRange(int viewid) {
		try {
			while (!Arrays.asList(topLimitArray).contains(
					String.valueOf(viewid))) {
				viewid--;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return viewid;
	}

	int getLeftRange(int viewid) {
		try {
			while (!Arrays.asList(leftLimitArray).contains(
					String.valueOf(viewid))) {
				viewid = viewid - 8;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return viewid;
	}

	void get7digitEquation(int result) {
		try {
			int counter = 0;
			for (int outercount = 0; outercount <= 9; outercount++) {
				for (int innnercount = 0; innnercount <= 9; innnercount++) {
					{
						for (int innercount_2 = 0; innercount_2 <= 9; innercount_2++) {
							for (int innercount_3 = 0; innercount_3 <= 9; innercount_3++) {
								if (outercount != 0 && innnercount != 0
										&& innercount_2 != 0
										&& innercount_3 != 0) {
									if (outercount - innnercount + innercount_2
											- innercount_3 == result) {
										seven_DigitEquationArraylist.add(String
												.valueOf(outercount));
										seven_DigitEquationArraylist.add("-");
										seven_DigitEquationArraylist.add(String
												.valueOf(innnercount));
										seven_DigitEquationArraylist.add("+");
										seven_DigitEquationArraylist.add(String
												.valueOf(innercount_2));
										seven_DigitEquationArraylist.add("-");
										seven_DigitEquationArraylist.add(String
												.valueOf(innercount_3));
										counter++;
									}
									if (outercount + innnercount - innercount_2
											+ innercount_3 == result) {
										seven_DigitEquationArraylist.add(String
												.valueOf(outercount));
										seven_DigitEquationArraylist.add("+");
										seven_DigitEquationArraylist.add(String
												.valueOf(innnercount));
										seven_DigitEquationArraylist.add("-");
										seven_DigitEquationArraylist.add(String
												.valueOf(innercount_2));
										seven_DigitEquationArraylist.add("+");
										seven_DigitEquationArraylist.add(String
												.valueOf(innercount_3));
										counter++;
									}
									if (innercount_3 - innercount_2
											- innnercount - outercount == result) {
										seven_DigitEquationArraylist.add(String
												.valueOf(innercount_3));
										seven_DigitEquationArraylist.add("-");
										seven_DigitEquationArraylist.add(String
												.valueOf(innercount_2));
										seven_DigitEquationArraylist.add("-");
										seven_DigitEquationArraylist.add(String
												.valueOf(innnercount));
										seven_DigitEquationArraylist.add("-");
										seven_DigitEquationArraylist.add(String
												.valueOf(outercount));
										counter++;
									}
								}
							}
						}
					}
				}

			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	void get3digitEquation(int result) {
		try {
			int counter = 0;
			for (int i = 0; i <= 9; i++) {
				for (int k = 0; k <= 9; k++) {
					{
						if (i != 0 && k != 0) {
							if (i + k == result) {
								three_DigitEquationArraylist.add(String
										.valueOf(i));
								three_DigitEquationArraylist.add("+");
								three_DigitEquationArraylist.add(String
										.valueOf(k));
								counter++;
							}
							if (k - i == result) {
								three_DigitEquationArraylist.add(String
										.valueOf(k));
								three_DigitEquationArraylist.add("-");
								three_DigitEquationArraylist.add(String
										.valueOf(i));
								counter++;
							}
						}
					}

				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		three_DigitEquationArraylist.removeAll(Collections.singleton(null));
	}

	String swapText_fiveseven(String text) {
		try {
			if (text.equals("+"))
				return "-";
			else
				return "+";
		} catch (Exception ex) {
			ex.printStackTrace();
			return "+";
		}
	}

	String swapText(String text) {
		try {
			String randomElement = elementsArray[getRandomBlankPosition(elementsArray.length)];
			String randomElement2 = elementsArray[getRandomBlankPosition(elementsArray.length)];
			if (text.equals("+"))
				return "-";
			else if (text.equals("-"))
				return "+";
			else {
				if (Integer.parseInt(randomElement) != Integer.parseInt(text))
					return randomElement;
				else
					return "+";
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return "4";
		}
	}

	void get5digitEquation(int result) {
		try {
			int counter = 0;
			for (int outercount = 0; outercount <= 9; outercount++) {
				for (int innnercount = 0; innnercount <= 9; innnercount++) {
					{
						for (int innercount_2 = 0; innercount_2 <= 9; innercount_2++) {
							if (outercount != 0 && innnercount != 0
									&& innercount_2 != 0) {
								if (outercount - innnercount + innercount_2 == result) {
									five_DigitEquationArraylist.add(String
											.valueOf(outercount));
									five_DigitEquationArraylist.add("-");
									five_DigitEquationArraylist.add(String
											.valueOf(innnercount));
									five_DigitEquationArraylist.add("+");
									five_DigitEquationArraylist.add(String
											.valueOf(innercount_2));
									counter++;
								}
								if (outercount + innnercount - innercount_2 == result) {
									five_DigitEquationArraylist.add(String
											.valueOf(outercount));
									five_DigitEquationArraylist.add("+");
									five_DigitEquationArraylist.add(String
											.valueOf(innnercount));
									five_DigitEquationArraylist.add("-");
									five_DigitEquationArraylist.add(String
											.valueOf(innercount_2));
									counter++;
								}
								if (innercount_2 - innnercount - outercount == result) {
									five_DigitEquationArraylist.add(String
											.valueOf(innercount_2));
									five_DigitEquationArraylist.add("-");
									five_DigitEquationArraylist.add(String
											.valueOf(innnercount));
									five_DigitEquationArraylist.add("-");
									five_DigitEquationArraylist.add(String
											.valueOf(outercount));
									counter++;
								}
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		five_DigitEquationArraylist.removeAll(Collections.singleton(null));
	}

	int getEquationCount(int digit) {

		if (digit == 3) {
			int eqnCount = r
					.nextInt((three_DigitEquationArraylist.size() - 4) - 0) + 0;
			if (eqnCount % 3 == 0) {
				return three_DigitEquationArraylist.size() - eqnCount;
			}
		} else if (digit == 5) {
			int eqnCount = r
					.nextInt((five_DigitEquationArraylist.size() - 6) - 0) + 0;
			if (eqnCount % 5 == 0) {
				return five_DigitEquationArraylist.size() - eqnCount;
			}

		} else if (digit == 7) {

			return sevendigitequationcount;

		}

		return 0;
	}

	void fillGameValues(int digits) {
		try {

			random3digitstart = threerandomposition[new Random()
					.nextInt(threerandomposition.length)];
			// First 3 digit Random Equation

			int randomswap3digit[] = { Integer.parseInt(random3digitstart) - 8 + 1 };
			threedigitequationcount = getEquationCount(3);
			if (threedigitequationcount >= three_DigitEquationArraylist.size() - 1) {
				threedigitequationcount = 0;
			}
			Button threedigitequation_button1 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(random3digitstart));
			threedigitequation_button1.setText(three_DigitEquationArraylist
					.get(threedigitequationcount));
			Button threedigitequation_button2 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(random3digitstart) + 1);
			threedigitequation_button2.setText(three_DigitEquationArraylist
					.get(threedigitequationcount + 1));
			Button threedigitequation_button3 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(random3digitstart) + 2);
			threedigitequation_button3.setText(three_DigitEquationArraylist
					.get(threedigitequationcount + 2));
			randomswapposition_3digit = randomswap3digit[new Random()
					.nextInt(randomswap3digit.length)];
			Button randomswapButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_3digit);
			threedigitresultindex = randomswapposition_3digit;
			Button currentButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_3digit + 8);
			String currentBtnText = currentButton.getText().toString();
			currentButton.setText(swapText(currentButton.getText().toString()));
			try {
				randomswapButton.setText(currentBtnText);
				Button extraSign_Button1 = (Button) GameActivity.gameLinearLayout
						.findViewById(randomswapposition_3digit - 2);
				extraSign_Button1.setText("-");
				Button extraSign_Button2 = (Button) GameActivity.gameLinearLayout
						.findViewById(randomswapposition_3digit + 2);
				extraSign_Button2.setText("-");
				Button extraSign_Button3 = (Button) GameActivity.gameLinearLayout
						.findViewById(randomswapposition_3digit + 8 + 8);
				extraSign_Button3.setText("-");
				Button extraSign_Button4 = (Button) GameActivity.gameLinearLayout
						.findViewById(randomswapposition_3digit - 8);
				extraSign_Button4.setText("-");
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			// second three digit store
			// First 3 digit Random Equation
			random3digitstart = threerandomposition[new Random()
					.nextInt(threerandomposition.length)];
			int randomswap3digit2[] = {
					Integer.parseInt(random3digitstart) - 8,
					Integer.parseInt(random3digitstart) - 8 + 2 };
			threedigitequationcount = getEquationCount(3);
			if (threedigitequationcount >= three_DigitEquationArraylist.size() - 1) {
				threedigitequationcount = 0;
			}
			threedigitequation_button1 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(random3digitstart));
			threedigitequation_button1.setText(three_DigitEquationArraylist
					.get(threedigitequationcount));
			threedigitequation_button2 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(random3digitstart) + 1);
			threedigitequation_button2.setText(three_DigitEquationArraylist
					.get(threedigitequationcount + 1));
			threedigitequation_button3 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(random3digitstart) + 2);
			threedigitequation_button3.setText(three_DigitEquationArraylist
					.get(threedigitequationcount + 2));
			randomswapposition_3digit = randomswap3digit2[new Random()
					.nextInt(randomswap3digit.length)];
			randomswapButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_3digit);
			threedigitresultindex = randomswapposition_3digit;
			currentButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_3digit + 8);
			currentBtnText = currentButton.getText().toString();
			currentButton.setText(swapText(currentButton.getText().toString()));
			try {
				randomswapButton.setText(currentBtnText);
				Button extraSign_Button1 = (Button) GameActivity.gameLinearLayout
						.findViewById(threedigitequationcount - 16 - 1);
				extraSign_Button1.setText("+");
				Button extraSign_Button2 = (Button) GameActivity.gameLinearLayout
						.findViewById(randomswapposition_3digit + 2);
				extraSign_Button2.setText("-");
				Button extraSign_Button3 = (Button) GameActivity.gameLinearLayout
						.findViewById(randomswapposition_3digit + 8 + 8);
				extraSign_Button3.setText("-");
				Button extraSign_Button4 = (Button) GameActivity.gameLinearLayout
						.findViewById(randomswapposition_3digit - 8);
				extraSign_Button4.setText("-");
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			// Fisrt Five digit equation
			fivedigitstart = fiverandomposition[new Random()
					.nextInt(fiverandomposition.length)];
			fivedigitequationcount = getEquationCount(5);
			if (fivedigitequationcount >= five_DigitEquationArraylist.size() - 1) {
				fivedigitequationcount = 0;
			}
			int randomswap5digit[] = { Integer.parseInt(fivedigitstart) + 16 + 1 };
			Button fivedigitequation_button1 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(fivedigitstart));
			fivedigitequation_button1.setText(five_DigitEquationArraylist
					.get(fivedigitequationcount));
			fivedigitequationcount++;
			Button fivedigitequation_button2 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(fivedigitstart) + 8);
			fivedigitequation_button2.setText(five_DigitEquationArraylist
					.get(fivedigitequationcount));
			fivedigitequationcount++;
			Button fivedigitequation_button3 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(fivedigitstart) + 16);
			fivedigitequation_button3.setText(five_DigitEquationArraylist
					.get(fivedigitequationcount));
			fivedigitequationcount++;
			Button fivedigitequation_button4 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(fivedigitstart) + 24);
			fivedigitequation_button4.setText(five_DigitEquationArraylist
					.get(fivedigitequationcount));
			fivedigitequationcount++;
			Button fivedigitequation_button5 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(fivedigitstart) + 32);
			fivedigitequation_button5.setText(five_DigitEquationArraylist
					.get(fivedigitequationcount));
			fivedigitequationcount++;
			if (fivedigitequationcount == five_DigitEquationArraylist.size()) {
				fivedigitequationcount = 0;
			}

			randomswapposition_5digit = randomswap5digit[new Random()
					.nextInt(randomswap5digit.length)];
			randomswapButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_5digit);
			fivesevendigitresultindex = randomswapposition_5digit;
			currentButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_5digit - 1);
			currentBtnText = currentButton.getText().toString();
			currentButton.setText(swapText(currentButton.getText().toString()));

			randomswapButton.setText(currentBtnText);

			Button extraSign_Button1 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_5digit - 8);
			extraSign_Button1.setText("-");
			Button extraSign_Button2 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_5digit + 8);
			extraSign_Button2.setText("-");
			Button extraSign_Button3 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_5digit - 8 - 8);
			extraSign_Button3.setText("-");
			Button extraSign_Button4 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_5digit - 8 - 8 - 8);
			extraSign_Button4.setText("-");

			// First 7 digit Equation
			sevendigitstart = sevenrandomposition[new Random()
					.nextInt(sevenrandomposition.length)];
			sevendigitequationcount = getEquationCount(7);
			if (sevendigitequationcount >= seven_DigitEquationArraylist.size() - 1
					&& seven_DigitEquationArraylist
							.get(sevendigitequationcount) != null) {
				sevendigitequationcount = 0;
			}
			int randomswap7digit[] = { Integer.parseInt(sevendigitstart) + 32 + 1, };
			Button sevendigitequation_button1 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(sevendigitstart));
			sevendigitequation_button1.setText(seven_DigitEquationArraylist
					.get(sevendigitequationcount));
			sevendigitequationcount++;
			Button sevendigitequation_button2 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(sevendigitstart) + 8);
			sevendigitequation_button2.setText(seven_DigitEquationArraylist
					.get(sevendigitequationcount));
			sevendigitequationcount++;
			Button sevendigitequation_button3 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(sevendigitstart) + 16);
			sevendigitequation_button3.setText(seven_DigitEquationArraylist
					.get(sevendigitequationcount));
			sevendigitequationcount++;
			Button sevendigitequation_button4 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(sevendigitstart) + 24);
			sevendigitequation_button4.setText(seven_DigitEquationArraylist
					.get(sevendigitequationcount));
			sevendigitequationcount++;
			Button sevendigitequation_button5 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(sevendigitstart) + 32);
			sevendigitequation_button5.setText(seven_DigitEquationArraylist
					.get(sevendigitequationcount));
			sevendigitequationcount++;
			Button sevendigitequation_button6 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(sevendigitstart) + 40);
			sevendigitequation_button6.setText(seven_DigitEquationArraylist
					.get(sevendigitequationcount));
			sevendigitequationcount++;
			Button sevendigitequation_button7 = (Button) GameActivity.gameLinearLayout
					.findViewById(Integer.parseInt(sevendigitstart) + 48);
			sevendigitequation_button7.setText(seven_DigitEquationArraylist
					.get(sevendigitequationcount));
			sevendigitequationcount++;

			randomswapposition_7digit = randomswap7digit[new Random()
					.nextInt(randomswap7digit.length)];
			randomswapButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_7digit);
			fivesevendigitresultindex = randomswapposition_7digit;
			currentButton = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_7digit - 1);
			currentBtnText = currentButton.getText().toString();
			currentButton.setText(swapText(currentButton.getText().toString()));

			randomswapButton.setText(currentBtnText);
			extraSign_Button1 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_7digit - 8);
			extraSign_Button1.setText("+");
			extraSign_Button2 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_7digit + 8);
			extraSign_Button2.setText("-");
			extraSign_Button3 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_7digit - 8 - 8);
			extraSign_Button3.setText("+");
			extraSign_Button4 = (Button) GameActivity.gameLinearLayout
					.findViewById(randomswapposition_7digit - 8 - 8 - 8);
			extraSign_Button4.setText("-");
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
