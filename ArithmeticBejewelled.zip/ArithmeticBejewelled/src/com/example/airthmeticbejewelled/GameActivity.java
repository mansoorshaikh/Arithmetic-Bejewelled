package com.example.airthmeticbejewelled;

import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.DisplayMetrics;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class GameActivity extends Activity {
	private static final String FORMAT = "%02d:%02d:%02d";
	LinearLayout gridLinearLayout;
	LayoutParams gridLayoutParams;
	public static RelativeLayout gameLinearLayout;
	public static Button tempSwipeButton1, tempSwipeButton2;
	public static RelativeLayout tempswipeRelativeLayout;
	private float mPrevX;
	private float mPrevY;
	int touchcounter = 0;
	GameFunctions gameFunctions;
	public static TextView resultTextView, scoreTextView;
	TextView timerTextView, timerNameTextView, scoreNameTextView,
			resultNameTextView;
	public static String directionString = "";
	public static int marginSet = 0;
	Button option, inventory, rgame;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.secondpage);

		option = (Button) findViewById(R.id.button3);
		inventory = (Button) findViewById(R.id.button4);
		rgame = (Button) findViewById(R.id.button5);

		option.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent option = new Intent(GameActivity.this,
						OptionActivity.class);
				startActivity(option);
			}
		});
		rgame.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				AlertDialog.Builder builder = new AlertDialog.Builder(GameActivity.this);
				builder.setMessage("Do you want to reset the game?")
				   .setCancelable(false)
				   .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				       public void onClick(DialogInterface dialog, int id) {
				    	   clearGameValues();
				       }
				   })
				   .setNegativeButton("No", new DialogInterface.OnClickListener() {
				       public void onClick(DialogInterface dialog, int id) {
				    	   dialog.dismiss();
				       }
				   });
				AlertDialog alert = builder.create();
				alert.show();
				
			}

		});

		tempSwipeButton1 = new Button(GameActivity.this);
		tempSwipeButton2 = new Button(GameActivity.this);
		tempSwipeButton1.setBackgroundResource(R.drawable.buttonbg1);
		tempSwipeButton2.setBackgroundResource(R.drawable.buttonbg2);
		tempswipeRelativeLayout = new RelativeLayout(GameActivity.this);
		gameFunctions = new GameFunctions(GameActivity.this);
		gameLinearLayout = new RelativeLayout(GameActivity.this);
		resultTextView = (TextView) findViewById(R.id.resultTextView);
		scoreTextView = (TextView) findViewById(R.id.scoreTextView);
		scoreTextView.setText("0");
		gridLinearLayout = (LinearLayout) findViewById(R.id.gridLinearLayout);
		Random r = new Random();
		gameFunctions.result = r.nextInt(14 - 7) + 7;
		System.out.println("result" + gameFunctions.result);
		resultTextView.setText(String.valueOf(gameFunctions.result));
		gameFunctions.get7digitEquation(gameFunctions.result);
		gameFunctions.get3digitEquation(gameFunctions.result);
		gameFunctions.get5digitEquation(gameFunctions.result);
		timerTextView = (TextView) findViewById(R.id.timerTextView);

		timerNameTextView = (TextView) findViewById(R.id.timerNameTextView);
		scoreNameTextView = (TextView) findViewById(R.id.scoreNameTextView);
		resultNameTextView = (TextView) findViewById(R.id.resultNameTextView);

		timerNameTextView.setTypeface(gameFunctions.font);
		scoreNameTextView.setTypeface(gameFunctions.font);
		resultNameTextView.setTypeface(gameFunctions.font);

		resultTextView.setTypeface(gameFunctions.font);
		scoreTextView.setTypeface(gameFunctions.font);
		timerTextView.setTypeface(gameFunctions.font);
		fillGameContents();

		startTimer();
	}

	void checkCombination(Button selectedBtn, String movement) {

	}

	void fillGameContents() {
		gameLinearLayout.removeAllViews();
		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;
		gridLinearLayout.removeAllViews();
		LayoutParams gridLayoutParams = (LayoutParams) gridLinearLayout
				.getLayoutParams();
		gridLayoutParams.setMargins((width * 1) / 100, (height * 2) / 100,
				(width * 1) / 100, 0);
		gridLinearLayout.setLayoutParams(gridLayoutParams);
		final int gamewidth = width - ((width * 2) / 100);
		RelativeLayout.LayoutParams gameLayoutParams = new RelativeLayout.LayoutParams(
				gamewidth, gamewidth);
		gameLinearLayout.setBackgroundResource(R.drawable.border);
		gameLinearLayout.setLayoutParams(gameLayoutParams);
		for (int outercount = 1; outercount < 65; outercount++) {
			final Button eqnButton = new Button(GameActivity.this);
			RelativeLayout.LayoutParams eqnLayoutParams = new RelativeLayout.LayoutParams(
					gamewidth / 8, gamewidth / 8);
			if (outercount != 1) {
				if (!Arrays.asList(gameFunctions.topLimitArray).contains(
						String.valueOf(outercount))) {
					eqnLayoutParams.addRule(RelativeLayout.BELOW,
							outercount - 1);
					if (!Arrays.asList(gameFunctions.leftLimitArray).contains(
							String.valueOf(outercount)))
						eqnLayoutParams.addRule(RelativeLayout.RIGHT_OF,
								outercount - 8);
				} else {
					Button leftButton = (Button) gameLinearLayout
							.findViewById(outercount - 8);
					eqnLayoutParams.addRule(RelativeLayout.RIGHT_OF,
							leftButton.getId());
				}
			}

			eqnButton.setOnDragListener(new OnDragListener() {

				@Override
				public boolean onDrag(View v, DragEvent event) {
					// TODO Auto-generated method stub
					int action = event.getAction();
					float currX, currY;
					switch (action) {
					case DragEvent.ACTION_DROP:
						currX = event.getX();
						currY = event.getY();
					}
					return true;
				}
			});

			eqnButton.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					// TODO Auto-generated method stub
					float currX, currY;
					int action = event.getAction();
					Button currentButton = (Button) gameLinearLayout
							.findViewById(v.getId());
					switch (action) {
					case MotionEvent.ACTION_DOWN: {
						touchcounter = 0;
						mPrevX = event.getRawX();
						mPrevY = event.getRawY();
						if (marginSet == 0) {
							marginSet = 1;
						}
						return true;
					}

					case MotionEvent.ACTION_UP: {
						try {
							currX = event.getRawX();
							currY = event.getRawY();
							if (touchcounter == 0) {
								if ((currY - mPrevY) > 100) {
									if (!Arrays
											.asList(gameFunctions.bottomLimitArray)
											.contains(
													String.valueOf(currentButton
															.getId()))) {
										System.out.println("Moved Down");
										directionString = "down";
										gameFunctions.currentLeftLimit = gameFunctions
												.getLeftRange(v.getId() + 1);
										gameFunctions.currenttoplimit = gameFunctions
												.getTopRange(v.getId() + 1);
										gameFunctions.currentSwipedButton = (Button) gameLinearLayout
												.findViewById(v.getId());
										gameFunctions.currentRowSelectedButton = (Button) gameLinearLayout
												.findViewById(v.getId() + 1);

										// temp button 1
										RelativeLayout.LayoutParams tempSwipeButton1_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.topLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId())))
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId() - 1);
										if (!Arrays
												.asList(gameFunctions.leftLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId())))
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId() - 8);

										if (currentButton.getId() == 1) {
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															2);
										}
										tempSwipeButton1
												.setLayoutParams(tempSwipeButton1_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton1);

										Animation a = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton1
														.getLayoutParams();
												params.topMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton1
														.setLayoutParams(params);
											}
										};
										a.setDuration(500);
										tempSwipeButton1.startAnimation(a);

										// temp button 2

										RelativeLayout.LayoutParams tempSwipeButton2_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.topLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId() + 2)))
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.ABOVE,
															currentButton
																	.getId() + 2);
										else
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId());
										if (!Arrays
												.asList(gameFunctions.leftLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId())))
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId() - 8 + 1);

										tempSwipeButton2
												.setLayoutParams(tempSwipeButton2_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton2);

										Animation a2 = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton2
														.getLayoutParams();
												params.bottomMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton2
														.setLayoutParams(params);
											}
										};
										a2.setDuration(500);
										tempSwipeButton2.startAnimation(a2);

										a2.setAnimationListener(new Animation.AnimationListener() {
											@Override
											public void onAnimationStart(
													Animation animation) {

											}

											@Override
											public void onAnimationEnd(
													Animation animation) {
												String currentswipetext = gameFunctions.currentRowSelectedButton
														.getText().toString();
												gameFunctions.currentRowSelectedButton
														.setText(gameFunctions.currentSwipedButton
																.getText()
																.toString());
												gameFunctions.currentSwipedButton
														.setText(currentswipetext);
												gameFunctions.matchEquations();
											}

											@Override
											public void onAnimationRepeat(
													Animation animation) {

											}
										});
									}
								}
								if ((currY - mPrevY) < -100) {
									if (!Arrays
											.asList(gameFunctions.topLimitArray)
											.contains(
													String.valueOf(currentButton
															.getId()))) {
										System.out.println("Moved Up");
										directionString = "up";
										gameFunctions.currentLeftLimit = gameFunctions
												.getLeftRange(v.getId() - 1);
										gameFunctions.currenttoplimit = gameFunctions
												.getTopRange(v.getId() - 1);
										gameFunctions.currentSwipedButton = (Button) gameLinearLayout
												.findViewById(v.getId());
										gameFunctions.currentRowSelectedButton = (Button) gameLinearLayout
												.findViewById(v.getId() - 1);

										RelativeLayout.LayoutParams tempSwipeButton1_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.bottomLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId())))
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.ABOVE,
															currentButton
																	.getId() + 1);
										else
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId() - 1);
										if (!Arrays
												.asList(gameFunctions.leftLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId())))
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId() - 8);
										else
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.LEFT_OF,
															currentButton
																	.getId() + 8);
										tempSwipeButton1
												.setLayoutParams(tempSwipeButton1_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton1);

										Animation a = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton1
														.getLayoutParams();
												params.bottomMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton1
														.setLayoutParams(params);
											}
										};
										a.setDuration(500); // in ms
										tempSwipeButton1.startAnimation(a);

										RelativeLayout.LayoutParams tempSwipeButton2_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.topLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId() - 2))
												&& !Arrays
														.asList(gameFunctions.topLimitArray)
														.contains(
																String.valueOf(currentButton
																		.getId() - 1)))
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId() - 2);
										else
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.ABOVE,
															currentButton
																	.getId());

										if (!Arrays
												.asList(gameFunctions.leftLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId() - 8 - 1)))
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId() - 8 - 1);
										else
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.LEFT_OF,
															currentButton
																	.getId() + 8 - 1);
										tempSwipeButton2
												.setLayoutParams(tempSwipeButton2_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton2);
										Animation a2 = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton2
														.getLayoutParams();
												params.topMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton2
														.setLayoutParams(params);
											}
										};
										a2.setDuration(500); // in ms
										tempSwipeButton2.startAnimation(a2);

										a2.setAnimationListener(new Animation.AnimationListener() {
											@Override
											public void onAnimationStart(
													Animation animation) {

											}

											@Override
											public void onAnimationEnd(
													Animation animation) {
												String currentswipetext = gameFunctions.currentRowSelectedButton
														.getText().toString();
												gameFunctions.currentRowSelectedButton
														.setText(gameFunctions.currentSwipedButton
																.getText()
																.toString());
												gameFunctions.currentSwipedButton
														.setText(currentswipetext);
												gameFunctions.matchEquations();
											}

											@Override
											public void onAnimationRepeat(
													Animation animation) {

											}
										});
									}
								} else if ((currX - mPrevX) < -100) {
									if (!Arrays
											.asList(gameFunctions.leftLimitArray)
											.contains(
													String.valueOf(currentButton
															.getId()))) {
										System.out.println("Moved Left");
										directionString = "left";
										gameFunctions.currentLeftLimit = gameFunctions
												.getLeftRange(v.getId() - 8);
										gameFunctions.currenttoplimit = gameFunctions
												.getTopRange(v.getId() - 8);
										gameFunctions.currentSwipedButton = (Button) gameLinearLayout
												.findViewById(v.getId());
										gameFunctions.currentRowSelectedButton = (Button) gameLinearLayout
												.findViewById(v.getId() - 8);

										RelativeLayout.LayoutParams tempSwipeButton1_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.bottomLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId() + 1)))
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.ABOVE,
															currentButton
																	.getId() + 1);
										else
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId() - 1);
										if ((currentButton.getId() + 16) < 64)
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.LEFT_OF,
															currentButton
																	.getId() + 8);
										else
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId() - 8);
										tempSwipeButton1
												.setLayoutParams(tempSwipeButton1_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton1);

										Animation a = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton1
														.getLayoutParams();
												params.rightMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton1
														.setLayoutParams(params);
											}
										};
										a.setDuration(500); // in ms
										tempSwipeButton1.startAnimation(a);

										RelativeLayout.LayoutParams tempSwipeButton2_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.topLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId() - 8 - 1)))
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId() - 8 - 1);
										else
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.ABOVE,
															currentButton
																	.getId() - 8 + 1);

										if ((currentButton.getId() - 16) > 0)
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId() - 8 - 8);
										else
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.LEFT_OF,
															currentButton
																	.getId() + 8);
										tempSwipeButton2
												.setLayoutParams(tempSwipeButton2_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton2);
										Animation a2 = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton2
														.getLayoutParams();
												params.leftMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton2
														.setLayoutParams(params);
											}
										};
										a2.setDuration(500); // in ms
										tempSwipeButton2.startAnimation(a2);

										a2.setAnimationListener(new Animation.AnimationListener() {
											@Override
											public void onAnimationStart(
													Animation animation) {

											}

											@Override
											public void onAnimationEnd(
													Animation animation) {
												String currentswipetext = gameFunctions.currentRowSelectedButton
														.getText().toString();
												gameFunctions.currentRowSelectedButton
														.setText(gameFunctions.currentSwipedButton
																.getText()
																.toString());
												gameFunctions.currentSwipedButton
														.setText(currentswipetext);
												gameFunctions.matchEquations();
											}

											@Override
											public void onAnimationRepeat(
													Animation animation) {

											}
										});
									}
								} else if ((currX - mPrevX) > 100) {
									if (!Arrays
											.asList(gameFunctions.rightLimitArray)
											.contains(
													String.valueOf(currentButton
															.getId()))) {
										System.out.println("Moved right");
										directionString = "right";
										gameFunctions.currentLeftLimit = gameFunctions
												.getLeftRange(v.getId() + 8);
										gameFunctions.currenttoplimit = gameFunctions
												.getTopRange(v.getId() + 8);
										gameFunctions.currentSwipedButton = (Button) gameLinearLayout
												.findViewById(v.getId());
										gameFunctions.currentRowSelectedButton = (Button) gameLinearLayout
												.findViewById(v.getId() + 8);

										RelativeLayout.LayoutParams tempSwipeButton1_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.bottomLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId() + 1)))
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.ABOVE,
															currentButton
																	.getId() + 1);
										else
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId() - 1);
										if ((currentButton.getId() - 8) > 0)
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId() - 8);
										else
											tempSwipeButton1_layoutparams
													.addRule(
															RelativeLayout.LEFT_OF,
															currentButton
																	.getId() + 8);
										tempSwipeButton1
												.setLayoutParams(tempSwipeButton1_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton1);

										Animation a = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton1
														.getLayoutParams();
												params.leftMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton1
														.setLayoutParams(params);
											}
										};
										a.setDuration(500); // in ms
										tempSwipeButton1.startAnimation(a);

										RelativeLayout.LayoutParams tempSwipeButton2_layoutparams = new RelativeLayout.LayoutParams(
												gamewidth / 8, gamewidth / 8);
										if (!Arrays
												.asList(gameFunctions.topLimitArray)
												.contains(
														String.valueOf(currentButton
																.getId() + 8 - 1)))
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.BELOW,
															currentButton
																	.getId() + 8 - 1);
										else
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.ABOVE,
															currentButton
																	.getId() + 8 + 1);

										if ((currentButton.getId() + 16) < 64)
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.LEFT_OF,
															currentButton
																	.getId() + 8 + 8);
										else
											tempSwipeButton2_layoutparams
													.addRule(
															RelativeLayout.RIGHT_OF,
															currentButton
																	.getId());
										tempSwipeButton2
												.setLayoutParams(tempSwipeButton2_layoutparams);
										gameLinearLayout
												.addView(tempSwipeButton2);
										Animation a2 = new Animation() {

											@Override
											protected void applyTransformation(
													float interpolatedTime,
													Transformation t) {
												RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tempSwipeButton2
														.getLayoutParams();
												params.rightMargin = (int) (gamewidth / 8 * interpolatedTime);
												tempSwipeButton2
														.setLayoutParams(params);
											}
										};
										a2.setDuration(500); // in ms
										tempSwipeButton2.startAnimation(a2);

										a2.setAnimationListener(new Animation.AnimationListener() {
											@Override
											public void onAnimationStart(
													Animation animation) {

											}

											@Override
											public void onAnimationEnd(
													Animation animation) {
												String currentswipetext = gameFunctions.currentRowSelectedButton
														.getText().toString();
												gameFunctions.currentRowSelectedButton
														.setText(gameFunctions.currentSwipedButton
																.getText()
																.toString());
												gameFunctions.currentSwipedButton
														.setText(currentswipetext);
												gameFunctions.matchEquations();
											}

											@Override
											public void onAnimationRepeat(
													Animation animation) {

											}
										});
									}
								}

								touchcounter = 1;
							}
							currX = 0;
							currY = 0;
						} catch (Exception ex) {
							ex.printStackTrace();
						}

					}

					case MotionEvent.ACTION_CANCEL:
						break;

					}

					return true;
				}

			});

			eqnButton.setBackgroundResource(R.drawable.numberbackground);

			eqnButton.setId(outercount);
			eqnButton
					.setText(gameFunctions.elementsArray[gameFunctions
							.getRandomBlankPosition(gameFunctions.elementsArray.length)]);
			eqnButton.setLayoutParams(eqnLayoutParams);
			gameLinearLayout.addView(eqnButton);
		}

		gridLinearLayout.addView(gameLinearLayout);

		gameFunctions.fillGameValues(0);

		// gameFunctions.checkGridForDefaultEquations();
	}

	private void shuffleArrayList() {

	}

	void startTimer() {
		final CountDownTimer timer = new CountDownTimer(120000, 1000) {
			public void onTick(long millisUntilFinished) {

				timerTextView
						.setText(""
								+ String.format(
										FORMAT,
										TimeUnit.MILLISECONDS
												.toHours(millisUntilFinished),
										TimeUnit.MILLISECONDS
												.toMinutes(millisUntilFinished)
												- TimeUnit.HOURS
														.toMinutes(TimeUnit.MILLISECONDS
																.toHours(millisUntilFinished)),
										TimeUnit.MILLISECONDS
												.toSeconds(millisUntilFinished)
												- TimeUnit.MINUTES
														.toSeconds(TimeUnit.MILLISECONDS
																.toMinutes(millisUntilFinished))));
			}

			public void onFinish() {
				timerTextView.setText("Time Up!");
				clearGameValues();

			}
		}.start();
	}

	void clearGameValues() {
		try {
			for (int cellcount = 1; cellcount < 65; cellcount++) {
				Button eqnButton = (Button) GameActivity.gameLinearLayout
						.findViewById(cellcount);
				eqnButton.setText("");
			}
			AlertDialog.Builder alert = new AlertDialog.Builder(
					GameActivity.this);

			alert.setTitle("The time is up!!! \nYour score is "
					+ String.valueOf(gameFunctions.score));
			alert.setMessage("Do you want to start new game");

			// Set an EditText view to get user input
			alert.setPositiveButton("Yes",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
							// Do something with value!
							Random r = new Random();
							gameFunctions.result = r.nextInt(14 - 7) + 7;
							gameFunctions.result = r.nextInt(14 - 7) + 7;
							System.out.println("result" + gameFunctions.result);
							resultTextView.setText(String
									.valueOf(gameFunctions.result));
							gameFunctions.seven_DigitEquationArraylist.clear();
							gameFunctions.five_DigitEquationArraylist.clear();
							gameFunctions.three_DigitEquationArraylist.clear();
							gameFunctions
									.get7digitEquation(gameFunctions.result);
							gameFunctions
									.get3digitEquation(gameFunctions.result);
							gameFunctions
									.get5digitEquation(gameFunctions.result);
							gameFunctions.score = 0;
							scoreTextView.setText("0");
							gameFunctions.threedigitequationcount = 0;
							gameFunctions.fivedigitequationcount = 0;
							gameFunctions.sevendigitequationcount = 0;
							fillGameContents();
							startTimer();
						}
					});

			alert.setNegativeButton("No",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
							// Canceled.
							Intent intent = new Intent(GameActivity.this,
									MainActivity.class);
							startActivity(intent);
						}
					});

			alert.show();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
