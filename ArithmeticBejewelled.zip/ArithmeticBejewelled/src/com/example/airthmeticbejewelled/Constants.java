package com.example.airthmeticbejewelled;

public class Constants {
	public static int threedigitequationsfor1 = 0;
}
