package com.example.airthmeticbejewelled;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.daimajia.numberprogressbar.NumberProgressBar;

public class ProgressBarActivity extends Activity {
	public static GameFunctions gameFunctions;
	ProgressBar mProgressBar;
	TextView progresstextview;
	LinearLayout progressbarlinearlayout;

	private int counter = 0;
	private Timer timer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.progressbar);
		gameFunctions = new GameFunctions(ProgressBarActivity.this);
		gameFunctions.mediaPlayer = MediaPlayer.create(
				ProgressBarActivity.this, R.raw.song);
		gameFunctions.mediaPlayer.setLooping(true);
		gameFunctions.mediaPlayer.start();

		progresstextview = (TextView) findViewById(R.id.progresstextview);

		DisplayMetrics displaymetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		int height = displaymetrics.heightPixels;
		int width = displaymetrics.widthPixels;

		progressbarlinearlayout = (LinearLayout) findViewById(R.id.progressbarlinearlayout);

		final NumberProgressBar numberProgressBar = (NumberProgressBar) findViewById(R.id.numberbar2);
		counter = 0;
		timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						numberProgressBar.incrementProgressBy(1);
						progresstextview.setText(String.valueOf(counter) + "%");
						counter++;
						if (counter == 101) {
							timer.cancel();
							counter = 0;

							Intent intent = new Intent(
									ProgressBarActivity.this,
									MainActivity.class);
							startActivity(intent);
						}
					}
				});
			}
		}, 800, 100);

	}

	public void onBackPressed() {

	};
}
