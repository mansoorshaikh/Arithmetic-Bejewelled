package com.example.airthmeticbejewelled;

import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

class ButtonAnimatorHelper {

	final RelativeLayout mButton;

	/**
	 * Default constructor
	 * 
	 * @param speakButton
	 */
	public ButtonAnimatorHelper(final RelativeLayout button) {
		mButton = button;
	}

	public void setMarginLeft(final int margin) {
		final ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) mButton
				.getLayoutParams();

		params.leftMargin = margin;

		mButton.setLayoutParams(params);
	}

	public void setMarginRight(final int margin) {
		final ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) mButton
				.getLayoutParams();

		params.rightMargin = margin;

		mButton.setLayoutParams(params);
	}

	public void setMarginTop(final int margin) {
		if (GameActivity.marginSet == 1) {
			final RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mButton
					.getLayoutParams();

			params.topMargin = margin;

			mButton.setLayoutParams(params);
		}
	}

	public void setMarginBottom(final int margin) {
		final ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) mButton
				.getLayoutParams();

		params.bottomMargin = margin;

		mButton.setLayoutParams(params);
	}
}
