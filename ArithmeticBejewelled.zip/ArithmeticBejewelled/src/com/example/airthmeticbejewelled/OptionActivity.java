package com.example.airthmeticbejewelled;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class OptionActivity extends Activity {

	public static Typeface font;
	TextView autohinttextview, helpoptiontextview, soundsettingtextview,
			mutetextview, volumetextview;
	Button mutebtn, volumebtn;
	private SeekBar volumeSeekbar = null;
	private AudioManager audioManager = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setVolumeControlStream(AudioManager.STREAM_MUSIC);
		setContentView(R.layout.option_activity);

		font = Typeface.createFromAsset(getAssets(), "mv-boli.ttf");

		autohinttextview = (TextView) findViewById(R.id.autohinttextview);
		autohinttextview.setTypeface(font);
		soundsettingtextview = (TextView) findViewById(R.id.soundsettingtextview);
		soundsettingtextview.setTypeface(font);
		mutetextview = (TextView) findViewById(R.id.mutetextview);
		mutetextview.setTypeface(font);
		volumetextview = (TextView) findViewById(R.id.volumetextview);
		volumetextview.setTypeface(font);

		mutebtn = (Button) findViewById(R.id.mutebtn);
		mutebtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (ProgressBarActivity.gameFunctions.mediaPlayer.isPlaying()) {
					ProgressBarActivity.gameFunctions.mediaPlayer.pause();
					mutebtn.setBackgroundResource(R.drawable.mute);
				} else {
					ProgressBarActivity.gameFunctions.mediaPlayer.start();
					mutebtn.setBackgroundResource(R.drawable.volume);
				}

			}
		});

		volumebtn = (Button) findViewById(R.id.volumebtn);

		volumeSeekbar = (SeekBar) findViewById(R.id.volumeSeekbar);
		audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		volumeSeekbar.setMax(audioManager
				.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
		volumeSeekbar.setProgress(audioManager
				.getStreamVolume(AudioManager.STREAM_MUSIC));

		volumeSeekbar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {
			}

			@Override
			public void onStartTrackingTouch(SeekBar arg0) {
			}

			@Override
			public void onProgressChanged(SeekBar arg0, int progress,
					boolean arg2) {
				audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,
						progress, 0);
			}
		});

		volumebtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (volumeSeekbar.getVisibility() == View.GONE) {
					volumeSeekbar.setVisibility(View.VISIBLE);
				} else {
					volumeSeekbar.setVisibility(View.GONE);
				}
			}

		});

	}

}
