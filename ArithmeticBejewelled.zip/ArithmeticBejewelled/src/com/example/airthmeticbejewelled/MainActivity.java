package com.example.airthmeticbejewelled;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	Button newgame, inventory, option, help, facebook, sms, email;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		newgame = (Button) findViewById(R.id.newgame);
		option = (Button) findViewById(R.id.option);
		sms = (Button)findViewById(R.id.sms);
		email = (Button)findViewById(R.id.email);

		newgame.setOnClickListener(this);
		option.setOnClickListener(this);
		sms.setOnClickListener(this);
		email.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.newgame:
			Intent newgame = new Intent(getApplicationContext(),
					GameActivity.class);
			startActivity(newgame);
			break;
		case R.id.option:
			Intent option = new Intent(getApplicationContext(),
					OptionActivity.class);
			startActivity(option);
			break;
		case R.id.sms:
			Intent sms = new Intent(getApplicationContext(),
					SendSMS.class);
			startActivity(sms);
			break;
		case R.id.email:
			Intent i = new Intent(Intent.ACTION_SEND);
			i.setType("message/rfc822");
			i.putExtra(Intent.EXTRA_EMAIL,
					new String[] { "mansoor@mobiwebcode.com" });
			i.putExtra(Intent.EXTRA_SUBJECT, "Send Message");
			i.putExtra(Intent.EXTRA_TEXT,"");
			try {
				MainActivity.this.startActivity(Intent.createChooser(i, "Send mail..."));
			} catch (android.content.ActivityNotFoundException ex) {
				Toast.makeText(MainActivity.this, "There are no email clients installed.",
						Toast.LENGTH_SHORT).show();
			
			
		}
			break;
		}

	}
}


